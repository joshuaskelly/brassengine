--- @module pico
local pico = {}

function pico.test()
    print("MODULE LOADING IS WORKING!")
end

return pico